import React from 'react';
import './Banner.css';

function Banner() {
  return (
    <section className="banner-section">
      <div className="banner-container"></div>
    </section>
  );
}

export default Banner;
